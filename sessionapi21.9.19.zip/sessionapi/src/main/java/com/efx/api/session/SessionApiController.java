package com.efx.api.session;

import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;

import com.efx.api.session.pojos.LoginRequest;
import com.efx.api.session.pojos.LoginResponse;
import com.efx.api.session.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@RestController
@RequestMapping("/session")
@Api(description = "REST APIs related to User Session API")
public class SessionApiController {
	public static final String USERNAME_HEADER = "API_USERNAME";
	Logger logger = null;

   /* @Autowired
    RestTemplate restTemplate;*/
    
    @Autowired
    private UserService userService;
    
    @PostMapping("/login")
    @ApiOperation(value = "User login - Post username and password")
    @ApiResponses(value = {
    	@ApiResponse(code = 200, message = "Success|OK"),
        @ApiResponse(code = 400, message = "Something went wrong"), 
        @ApiResponse(code = 401, message = "not authorized!"),
        @ApiResponse(code = 403, message = "forbidden!!!"),
        @ApiResponse(code = 404, message = "not found!!!"),
        @ApiResponse(code = 422, message = "Invalid username/password supplied")})
    public LoginResponse login(
       /* @ApiParam("Username") @RequestParam String username, 
        @ApiParam("Password") @RequestParam String password
        */
    		@RequestBody @NotNull LoginRequest request
        ) {
    	String token=userService.signin(request.getUsername(), request.getPassword());
    	LoginResponse rs=new LoginResponse();
    	rs.setToken(token);
    	return rs;
    }
    @GetMapping("/logout")
    @ApiOperation("User Logout")
    @ApiResponses(value = {	@ApiResponse(code = 204, message = "Success|OK")})
    public String logout() {
    	String token=null;
		return userService.logout(token);
    }
}
